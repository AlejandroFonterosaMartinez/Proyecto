var searchData=
[
  ['categorias_5fmodel_0',['Categorias_model',['../class_categorias__model.html',1,'']]],
  ['conectar_1',['Conectar',['../class_conectar.html',1,'']]]
];
