var searchData=
[
  ['carrito_2ephp_0',['carrito.php',['../carrito_8php.html',1,'']]],
  ['carrusel_2ejs_1',['carrusel.js',['../carrusel_8js.html',1,'']]],
  ['categorias_5fcontrolador_2ephp_2',['categorias_controlador.php',['../categorias__controlador_8php.html',1,'']]],
  ['categorias_5fmodelo_2ephp_3',['categorias_modelo.php',['../categorias__modelo_8php.html',1,'']]],
  ['categorias_5fview_2ephp_4',['categorias_view.php',['../categorias__view_8php.html',1,'']]],
  ['conectar_2ephp_5',['Conectar.php',['../_conectar_8php.html',1,'']]],
  ['contador_5fcarrito_2ephp_6',['contador_carrito.php',['../contador__carrito_8php.html',1,'']]]
];
