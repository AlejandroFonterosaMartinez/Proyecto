var searchData=
[
  ['_24_0',['$',['../main_8js.html#a362c9dd4cc47ecb70ca94a062b292693',1,'main.js']]]
];
