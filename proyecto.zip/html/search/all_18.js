var searchData=
[
  ['x_0',['x',['../jquery_8min_8js.html#aec90c211248513365bccc43afdd81f3c',1,'jquery.min.js']]]
];
