var searchData=
[
  ['g_0',['g',['../jquery_8min_8js.html#a103df269476e78897c9c4c6cb8f4eb06',1,'jquery.min.js']]],
  ['get_5fcategorias_1',['get_categorias',['../class_categorias__model.html#a8d77cea5b57250da5077ecc08f830374',1,'Categorias_model']]],
  ['get_5fproductos_2',['get_productos',['../class_productos__model.html#a6c961fd29505205a341ba0fa9b34d700',1,'Productos_model']]],
  ['getuser_3',['getUser',['../class_user.html#ad46c847a2e2cbaeaac52ef48907099b4',1,'User']]]
];
