var searchData=
[
  ['productos_5fmodel_0',['Productos_model',['../class_productos__model.html',1,'']]]
];
