var searchData=
[
  ['_5f_5fconstruct_0',['__construct',['../class_categorias__model.html#a083480fdaba74ee6b8982bc357137ff7',1,'Categorias_model\__construct()'],['../class_productos__model.html#ac7fd679219f19110d40c3d3c31c3cf43',1,'Productos_model\__construct()']]]
];
