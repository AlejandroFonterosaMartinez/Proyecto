var searchData=
[
  ['r_0',['r',['../jquery_8min_8js.html#a07c0e0a63b5b484807c0331c78558c9e',1,'jquery.min.js']]],
  ['refresh_1',['refresh',['../owl_8carousel_8min_8js.html#afa8e0c0e0336a4473193f65837dd55fd',1,'owl.carousel.min.js']]]
];
