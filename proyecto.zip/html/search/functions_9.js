var searchData=
[
  ['selectcategorias_0',['selectCategorias',['../admin__cargar_8php.html#acaa65e2698241d2cb559618ac0ff39ec',1,'selectCategorias($con):&#160;admin_cargar.php'],['../admin__guardar_8php.html#acaa65e2698241d2cb559618ac0ff39ec',1,'selectCategorias($con):&#160;admin_guardar.php']]]
];
