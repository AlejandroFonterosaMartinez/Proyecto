var searchData=
[
  ['registro_2ephp_0',['registro.php',['../registro_8php.html',1,'']]],
  ['registro_5fcontrolador_2ephp_1',['registro_controlador.php',['../registro__controlador_8php.html',1,'']]],
  ['registro_5fmodelo_2ephp_2',['registro_modelo.php',['../registro__modelo_8php.html',1,'']]]
];
