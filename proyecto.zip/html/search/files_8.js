var searchData=
[
  ['perfil_2ephp_0',['perfil.php',['../perfil_8php.html',1,'']]],
  ['productos_2ephp_1',['productos.php',['../productos_8php.html',1,'']]],
  ['productos_5fcontrolador_2ephp_2',['productos_controlador.php',['../productos__controlador_8php.html',1,'']]],
  ['productos_5fmodelo_2ephp_3',['productos_modelo.php',['../productos__modelo_8php.html',1,'']]],
  ['productos_5fview_2ephp_4',['productos_view.php',['../productos__view_8php.html',1,'']]]
];
