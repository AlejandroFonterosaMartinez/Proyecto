var searchData=
[
  ['c_0',['C',['../jquery_8min_8js.html#adb5f7878ff2c93b56217c17c2ced51f6',1,'jquery.min.js']]],
  ['c_1',['c',['../jquery_8min_8js.html#abce695e0af988ece0826d9ad59b8160d',1,'c():&#160;jquery.min.js'],['../owl_8carousel_8min_8js.html#ad9d1ac02e33c4aed62ad517a7cb8b3fb',1,'c():&#160;owl.carousel.min.js']]],
  ['calcularedad_2',['calcularEdad',['../class_user_registration.html#a2b8c3daa56a1b0c5d153bbdbdd631dd4',1,'UserRegistration']]],
  ['cargar_5fcategorias_3',['cargar_categorias',['../productos__modelo_8php.html#a0283860797da12ff4699263ebb1ef943',1,'productos_modelo.php']]],
  ['cargar_5fconfiguracion_4',['cargar_configuracion',['../_conectar_8php.html#a443fe0e46bc0ae406661427a69430a81',1,'Conectar.php']]],
  ['carrito_2ephp_5',['carrito.php',['../carrito_8php.html',1,'']]],
  ['carrusel_2ejs_6',['carrusel.js',['../carrusel_8js.html',1,'']]],
  ['categorias_5fcontrolador_2ephp_7',['categorias_controlador.php',['../categorias__controlador_8php.html',1,'']]],
  ['categorias_5fmodel_8',['Categorias_model',['../class_categorias__model.html',1,'']]],
  ['categorias_5fmodelo_2ephp_9',['categorias_modelo.php',['../categorias__modelo_8php.html',1,'']]],
  ['categorias_5fview_2ephp_10',['categorias_view.php',['../categorias__view_8php.html',1,'']]],
  ['conectar_11',['Conectar',['../class_conectar.html',1,'']]],
  ['conectar_2ephp_12',['Conectar.php',['../_conectar_8php.html',1,'']]],
  ['conexion_13',['conexion',['../class_conectar.html#a5649dabd70fd599340df50f72dddc303',1,'Conectar']]],
  ['contador_5fcarrito_2ephp_14',['contador_carrito.php',['../contador__carrito_8php.html',1,'']]]
];
