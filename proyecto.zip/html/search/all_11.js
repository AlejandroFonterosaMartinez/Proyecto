var searchData=
[
  ['p_0',['p',['../jquery_8min_8js.html#ad1707b001240e9c8298830073364c8bf',1,'jquery.min.js']]],
  ['perfil_2ephp_1',['perfil.php',['../perfil_8php.html',1,'']]],
  ['productos_2ephp_2',['productos.php',['../productos_8php.html',1,'']]],
  ['productos_5fcontrolador_2ephp_3',['productos_controlador.php',['../productos__controlador_8php.html',1,'']]],
  ['productos_5fmodel_4',['Productos_model',['../class_productos__model.html',1,'']]],
  ['productos_5fmodelo_2ephp_5',['productos_modelo.php',['../productos__modelo_8php.html',1,'']]],
  ['productos_5fview_2ephp_6',['productos_view.php',['../productos__view_8php.html',1,'']]]
];
