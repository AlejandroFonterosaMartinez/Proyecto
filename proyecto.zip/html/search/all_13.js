var searchData=
[
  ['s_0',['s',['../jquery_8min_8js.html#ad9a7d92cb87932d25187fdec3ba1b621',1,'jquery.min.js']]],
  ['select_5fproductos_2ephp_1',['select_productos.php',['../select__productos_8php.html',1,'']]],
  ['selectcategorias_2',['selectCategorias',['../admin__cargar_8php.html#acaa65e2698241d2cb559618ac0ff39ec',1,'selectCategorias($con):&#160;admin_cargar.php'],['../admin__guardar_8php.html#acaa65e2698241d2cb559618ac0ff39ec',1,'selectCategorias($con):&#160;admin_guardar.php']]]
];
