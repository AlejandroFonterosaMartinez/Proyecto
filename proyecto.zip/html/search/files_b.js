var searchData=
[
  ['usuario_5fcontrolador_2ephp_0',['usuario_controlador.php',['../usuario__controlador_8php.html',1,'']]],
  ['usuario_5fmodelo_2ephp_1',['usuario_modelo.php',['../usuario__modelo_8php.html',1,'']]]
];
