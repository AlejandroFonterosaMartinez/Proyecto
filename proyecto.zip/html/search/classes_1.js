var searchData=
[
  ['logincontroller_0',['loginController',['../classlogin_controller.html',1,'']]]
];
