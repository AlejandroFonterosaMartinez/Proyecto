var searchData=
[
  ['jquery_0',['jQuery',['../owl_8carousel_8min_8js.html#a7896fa52ef01ab20eec312b34df5efdb',1,'owl.carousel.min.js']]],
  ['jquery_2emin_2ejs_1',['jquery.min.js',['../jquery_8min_8js.html',1,'']]]
];
