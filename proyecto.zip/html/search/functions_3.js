var searchData=
[
  ['c_0',['C',['../jquery_8min_8js.html#adb5f7878ff2c93b56217c17c2ced51f6',1,'jquery.min.js']]],
  ['calcularedad_1',['calcularEdad',['../class_user_registration.html#a2b8c3daa56a1b0c5d153bbdbdd631dd4',1,'UserRegistration']]],
  ['cargar_5fcategorias_2',['cargar_categorias',['../productos__modelo_8php.html#a0283860797da12ff4699263ebb1ef943',1,'productos_modelo.php']]],
  ['cargar_5fconfiguracion_3',['cargar_configuracion',['../_conectar_8php.html#a443fe0e46bc0ae406661427a69430a81',1,'Conectar.php']]],
  ['conexion_4',['conexion',['../class_conectar.html#a5649dabd70fd599340df50f72dddc303',1,'Conectar']]]
];
