var searchData=
[
  ['get_5fcategorias_0',['get_categorias',['../class_categorias__model.html#a8d77cea5b57250da5077ecc08f830374',1,'Categorias_model']]],
  ['get_5fproductos_1',['get_productos',['../class_productos__model.html#a6c961fd29505205a341ba0fa9b34d700',1,'Productos_model']]],
  ['getuser_2',['getUser',['../class_user.html#ad46c847a2e2cbaeaac52ef48907099b4',1,'User']]]
];
