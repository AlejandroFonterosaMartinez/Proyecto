var searchData=
[
  ['r_0',['r',['../jquery_8min_8js.html#a07c0e0a63b5b484807c0331c78558c9e',1,'jquery.min.js']]],
  ['refresh_1',['refresh',['../owl_8carousel_8min_8js.html#afa8e0c0e0336a4473193f65837dd55fd',1,'owl.carousel.min.js']]],
  ['register_2',['register',['../class_user_registration.html#a0d949cba10ce6c31ac7ab2d928dfe6b3',1,'UserRegistration']]],
  ['registro_2ephp_3',['registro.php',['../registro_8php.html',1,'']]],
  ['registro_5fcontrolador_2ephp_4',['registro_controlador.php',['../registro__controlador_8php.html',1,'']]],
  ['registro_5fmodelo_2ephp_5',['registro_modelo.php',['../registro__modelo_8php.html',1,'']]]
];
